<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EmailControllers extends CI_Controller 
{
	public function __construct() 
	{
        parent::__construct();
		
        
    }
	
	public function index()
    {
        // Load the Imap library
        $this->load->library('Imap');

        // Load the Imap configuration
        $config = $this->config->item('imap');

        // Check if the configuration is loaded successfully
        if (!$config) {
            echo 'Failed to load Imap configuration';
            return;
        }

        // Connect to the inbox
        if ($this->imap->connect($config)) {
            echo 'Connected to inbox successfully';

            // Now you can perform operations on the inbox, such as fetching emails, etc.
            $emails = $this->imap->fetch_emails('inbox');
            // Perform operations on $emails, such as displaying or processing them
        } else {
            echo 'Failed to connect to inbox';
        }
    }

     


}
