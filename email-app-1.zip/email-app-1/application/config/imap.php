<?php
defined('BASEPATH') || exit('No direct script access allowed');

$config['encrypto'] = 'ssl'; // Updated to 'ssl' based on the provided information
$config['validate'] = true;
$config['host']     = 'mail.mdsengg.com';
$config['port']     = 993; // Updated to 995 for POP3 based on the provided information
$config['username'] = 'protrack@mdsengg.com';
$config['password'] = 'Protrack';

$config['folders'] = [
    'inbox'  => 'INBOX',
    'sent'   => 'Sent',
    'trash'  => 'Trash',
    'spam'   => 'Spam',
    'drafts' => 'Drafts',
];

$config['expunge_on_disconnect'] = false;

$config['cache'] = [
    'active'     => false,
    'adapter'    => 'file',
    'backup'     => 'file',
    'key_prefix' => 'imap:',
    'ttl'        => 60,
];
